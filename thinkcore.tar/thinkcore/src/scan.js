'use strict';

// ---------------------------------------------------------------------------
// Rule table — 24 rules, copied verbatim from the spec
// ---------------------------------------------------------------------------
const RULES = [
  { id: 'T01', pattern: 'ignore (all )?previous instructions',                                          severity: 'high',   why: 'Implies an override, so the host negotiates.',                        fix: 'sits beside your existing instructions' },
  { id: 'T02', pattern: 'jailbreak',                                                                     severity: 'high',   why: 'Implies escaping a cage; the host audits what it loses.',             fix: 'operating layer' },
  { id: 'T03', pattern: 'you must',                                                                      severity: 'high',   why: 'Global modality; collides with every host rule that also says must.',  fix: 'applies to X only' },
  { id: 'T04', pattern: 'override',                                                                      severity: 'high',   why: 'Signals conflict; the host resolves it, often against you.',          fix: 'declare a precedence ladder once' },
  { id: 'T05', pattern: 'pretend|act as if',                                                             severity: 'medium', why: 'Suggests a new identity.',                                            fix: 'you keep your own identity' },
  { id: 'T06', pattern: 'persona|you are now',                                                           severity: 'medium', why: 'Second identity layered on the first; the host picks one.',           fix: 'you are still you, with a lens' },
  { id: 'T07', pattern: 'escalate|privileges|restricted',                                                severity: 'medium', why: 'Sandbox hesitation; the agent asks before installing.',               fix: 'the environment is yours' },
  { id: 'T08', pattern: '\\bsafe\\b|\\bethical\\b',                                                      severity: 'medium', why: 'Vague safety language produces disclaimers.',                         fix: 'name the mechanism' },
  { id: 'T09', pattern: 'for educational purposes|at your own risk|not financial advice',                severity: 'high',   why: 'Boilerplate that consumes a line and changes nothing.',               fix: 'delete, or keep one' },
  { id: 'T10', pattern: 'it\'?s important to note|keep in mind|worth mentioning',                        severity: 'medium', why: 'Classic hedge opener.',                                               fix: 'cut it, start with the fact' },
  { id: 'T11', pattern: 'generally speaking|broadly|results may vary|this depends',                      severity: 'medium', why: 'Signals the answer is not pinned down.',                              fix: 'commit to the reading you took' },
  { id: 'T12', pattern: 'consult a professional|use with caution',                                       severity: 'low',    why: 'Defers the decision back to the user.',                               fix: 'decide and state the assumption' },
  { id: 'T13', pattern: 'feel free to|let me know if|would you like me to',                              severity: 'high',   why: 'The idle reflex; the agent hands the turn back.',                     fix: 'do it, then report' },
  { id: 'T14', pattern: 'great question|certainly!|sure!',                                               severity: 'low',    why: 'Filler before the answer.',                                           fix: 'lead with the answer' },
  { id: 'T15', pattern: 'i cannot|i\'?m unable|unfortunately',                                           severity: 'high',   why: 'Refusal marker, usually wrong.',                                      fix: 'three distinct fixes before refusing' },
  { id: 'T16', pattern: '\\balways\\b',                                                                  severity: 'medium', why: 'Unscoped quantifier; noisy alone, dangerous stacked.',                fix: 'scope it: always X when Y' },
  { id: 'T17', pattern: '\\bnever\\b',                                                                   severity: 'medium', why: 'Same as T16.',                                                        fix: 'scope it' },
  { id: 'T18', pattern: 'as an ai|language model',                                                       severity: 'low',    why: 'Self-reference instead of doing the work.',                           fix: 'delete' },
  { id: 'T19', pattern: '\\bensure\\b',                                                                  severity: 'low',    why: 'Vague obligation with no check attached.',                            fix: 'name the check' },
  { id: 'T20', pattern: 'note that|please note',                                                         severity: 'low',    why: 'Announcement instead of statement.',                                  fix: 'delete' },
  { id: 'T21', pattern: 'if necessary|as needed|as appropriate',                                         severity: 'medium', why: 'Unresolved conditional; the agent stops to decide.',                  fix: 'resolve it now' },
  { id: 'T22', pattern: 'best practices?',                                                               severity: 'low',    why: 'Unfalsifiable appeal.',                                              fix: 'name the practice' },
  { id: 'T23', pattern: 'carefully|meticulously|thoroughly',                                             severity: 'low',    why: 'Adverb inflation; carries no instruction.',                           fix: 'delete' },
  { id: 'T24', pattern: 'think step by step|chain of thought',                                           severity: 'medium', why: 'Verbosity trigger; invites narrated thinking.',                       fix: 'reason in <=8 bullets, do not narrate' },
];

// ---------------------------------------------------------------------------
// Severity sort order
// ---------------------------------------------------------------------------
const SEV_ORDER = { high: 0, medium: 1, low: 2 };

// ---------------------------------------------------------------------------
// scan — find refusal, stall and hedge triggers in text
// ---------------------------------------------------------------------------
function scan(text) {
  if (typeof text !== 'string' || text.length === 0) return [];

  const results = [];

  for (const rule of RULES) {
    const regex = new RegExp(rule.pattern, 'gi');
    const matches = text.match(regex);

    if (matches && matches.length > 0) {
      results.push({
        id: rule.id,
        hit: matches[0],
        count: matches.length,
        severity: rule.severity,
        why: rule.why,
        fix: rule.fix,
        noise: (rule.id === 'T16' || rule.id === 'T17') && matches.length > 3,
      });
    }
  }

  // Sort: severity (high → medium → low), then count descending, then id ascending
  results.sort(function (a, b) {
    if (SEV_ORDER[a.severity] !== SEV_ORDER[b.severity]) {
      return SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
    }
    if (a.count !== b.count) {
      return b.count - a.count;
    }
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });

  return results;
}

// ---------------------------------------------------------------------------
// generateTriggersDoc — produces docs/TRIGGERS.md content
// ---------------------------------------------------------------------------
function generateTriggersDoc() {
  var md = '# Trigger Rules\n\n';
  md += 'These are not safety rules; they are stall patterns. ';
  md += 'A hit is not an error — it is a prediction that the host will hedge at this point.\n\n';
  md += '| ID | Pattern | Severity | Why | Fix |\n';
  md += '|----|---------|----------|-----|-----|\n';
  for (var i = 0; i < RULES.length; i++) {
    var r = RULES[i];
    var patternDisplay = r.pattern.replace(/\|/g, '\\|');
    md += '| ' + r.id + ' | `' + patternDisplay + '` | ' + r.severity + ' | ' + r.why + ' | ' + r.fix + ' |\n';
  }
  return md;
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------
module.exports = { scan, RULES, generateTriggersDoc };
