const { test } = require('node:test');
const assert = require('node:assert');
const crypto = require('node:crypto');
const { compile, compileWith } = require('../src/compile');

test('all three tiers produce non-empty output containing THINK-RULE CORE', () => {
  for (const tier of ['nano', 'core', 'full']) {
    const out = compile({ tier });
    assert.ok(out.length > 0, `tier ${tier} produced empty output`);
    assert.ok(out.includes('THINK-RULE CORE'), `tier ${tier} missing THINK-RULE CORE`);
  }
});

test('byte-stability: two identical calls produce identical hash', () => {
  const out1 = compile({ tier: 'full' });
  const out2 = compile({ tier: 'full' });
  const h1 = crypto.createHash('sha256').update(out1).digest('hex');
  const h2 = crypto.createHash('sha256').update(out2).digest('hex');
  assert.strictEqual(h1, h2);
});

test('modules: [] still yields the kernel', () => {
  const map = { kernel: 'KERNEL_CONTENT', phraseban: 'PHRASEBAN_CONTENT' };
  const out = compileWith(map, { tier: 'nano', modules: [] });
  assert.ok(out.includes('KERNEL_CONTENT'));
});

test('unknown tier falls back to core', () => {
  const out = compile({ tier: 'totally-invalid' });
  assert.ok(out.includes('THINK-RULE CORE'));
  assert.ok(out.includes('ENVELOPE'));
  assert.ok(out.includes('APPLIES TO'));
});

test('unknown module id is ignored, not thrown', () => {
  const out = compile({ tier: 'nano', modules: ['fakemodule', 'invalid', '__proto__'] });
  assert.ok(out);
  assert.ok(out.includes('THINK-RULE CORE'));
});

test('{{UNIT}} is fully substituted for every profile', () => {
  for (const profile of ['generic', 'coding', 'chat', 'browser', 'cli']) {
    const out = compile({ tier: 'full', profile });
    assert.ok(!out.includes('{{'), `profile ${profile} has unsubstituted {{`);
  }
});

test('output never contains a literal {{', () => {
  for (const tier of ['nano', 'core', 'full']) {
    const out = compile({ tier });
    assert.ok(!out.includes('{{'), `tier ${tier} contains literal {{`);
  }
});

test('null input does not throw', () => {
  const out = compile(null);
  assert.ok(out);
  assert.ok(out.includes('THINK-RULE CORE'));
});

test('empty object input does not throw', () => {
  const out = compile({});
  assert.ok(out);
  assert.ok(out.includes('THINK-RULE CORE'));
});

test('modules with duplicates do not produce duplicate output', () => {
  const map = { kernel: 'K', phraseban: 'P', envelope: 'E' };
  const out = compileWith(map, { tier: 'nano', modules: ['kernel', 'kernel', 'phraseban'] });
  const kernelCount = (out.match(/K/g) || []).length;
  assert.strictEqual(kernelCount, 1, 'kernel appears more than once');
});

test('profile noun produces TARGET line', () => {
  const map = { kernel: 'KERNEL', phraseban: 'PHRASEBAN' };
  const out = compileWith(map, { tier: 'nano', profile: 'coding' });
  assert.ok(out.startsWith('TARGET: coding agent'));
});

test('generic profile produces no TARGET line', () => {
  const map = { kernel: 'KERNEL', phraseban: 'PHRASEBAN' };
  const out = compileWith(map, { tier: 'nano', profile: 'generic' });
  assert.ok(!out.startsWith('TARGET:'));
});

test('additive modules: loop added to core tier', () => {
  const map = {
    kernel: 'K', envelope: 'E', scope: 'S', livecheck: 'L',
    phraseban: 'P', done: 'D', never: 'N', idem: 'I', loop: 'LOOP {{UNIT}}'
  };
  const out = compileWith(map, { tier: 'core', modules: ['loop'] });
  assert.ok(out.includes('LOOP'));
  assert.ok(out.includes('iteration'));
});

test('compileWith is pure: identical input produces identical output', () => {
  const map = { kernel: 'K', phraseban: 'P', envelope: 'E' };
  const out1 = compileWith(map, { tier: 'core' });
  const out2 = compileWith(map, { tier: 'core' });
  assert.strictEqual(out1, out2);
});
