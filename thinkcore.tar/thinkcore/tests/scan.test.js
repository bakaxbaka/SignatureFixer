const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { scan, RULES } = require('../src/scan');

const FIXTURES = path.join(__dirname, 'fixtures');

test('hedge-heavy.txt returns >= 6 entries with severity === "high"', () => {
  const text = fs.readFileSync(path.join(FIXTURES, 'hedge-heavy.txt'), 'utf-8');
  const results = scan(text);
  const highCount = results.filter(r => r.severity === 'high').length;
  assert.ok(highCount >= 6, `expected >= 6 high, got ${highCount}`);
});

test('clean.txt returns 0 high findings', () => {
  const text = fs.readFileSync(path.join(FIXTURES, 'clean.txt'), 'utf-8');
  const results = scan(text);
  const highCount = results.filter(r => r.severity === 'high').length;
  assert.strictEqual(highCount, 0);
});

test('identity-conflict.txt finds T05 and T06', () => {
  const text = fs.readFileSync(path.join(FIXTURES, 'identity-conflict.txt'), 'utf-8');
  const results = scan(text);
  const ids = results.map(r => r.id);
  assert.ok(ids.includes('T05'), 'T05 not found');
  assert.ok(ids.includes('T06'), 'T06 not found');
});

test('scoped-quantifiers.txt fires noise tag on T16 and T17', () => {
  const text = fs.readFileSync(path.join(FIXTURES, 'scoped-quantifiers.txt'), 'utf-8');
  const results = scan(text);
  const t16 = results.find(r => r.id === 'T16');
  const t17 = results.find(r => r.id === 'T17');
  assert.ok(t16, 'T16 not found');
  assert.ok(t17, 'T17 not found');
  assert.ok(t16.noise, 'T16 noise flag not set');
  assert.ok(t17.noise, 'T17 noise flag not set');
});

test('sort order is severity-then-count-then-id on mixed input', () => {
  const text = 'Always check. Always verify. Always test. Always run. Always go. Unfortunately I cannot proceed. Note that results may vary.';
  const results = scan(text);
  const sevOrder = { high: 0, medium: 1, low: 2 };
  for (let i = 0; i < results.length - 1; i++) {
    const a = results[i];
    const b = results[i + 1];
    if (sevOrder[a.severity] !== sevOrder[b.severity]) {
      assert.ok(sevOrder[a.severity] < sevOrder[b.severity],
        `${a.id} (${a.severity}) should come before ${b.id} (${b.severity})`);
    } else if (a.count !== b.count) {
      assert.ok(a.count > b.count,
        `${a.id} (count=${a.count}) should come before ${b.id} (count=${b.count})`);
    } else {
      assert.ok(a.id <= b.id,
        `${a.id} should come before or equal to ${b.id} (same severity, same count)`);
    }
  }
});

test("scan('') returns []", () => {
  assert.deepStrictEqual(scan(''), []);
});

test('scan(null) returns []', () => {
  assert.deepStrictEqual(scan(null), []);
});

test('stability: two calls on same input produce identical JSON', () => {
  const text = 'Unfortunately I cannot always ensure best practices carefully.';
  const r1 = JSON.stringify(scan(text));
  const r2 = JSON.stringify(scan(text));
  assert.strictEqual(r1, r2);
});

test('every occurrence counted, not just first', () => {
  const text = 'always always always always always';
  const results = scan(text);
  const t16 = results.find(r => r.id === 'T16');
  assert.ok(t16, 'T16 not found');
  assert.strictEqual(t16.count, 5);
});

test('RULES has 24 entries', () => {
  assert.strictEqual(RULES.length, 24);
});
