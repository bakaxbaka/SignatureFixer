const { test } = require('node:test');
const assert = require('node:assert');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const PAYLOADS_DIR = path.join(ROOT, 'payloads');
const HASH_FILE = path.join(__dirname, 'payloads.sha256');

const PAYLOAD_FILES = [
  'kernel.txt', 'envelope.txt', 'scope.txt', 'livecheck.txt', 'phraseban.txt',
  'loop.txt', 'done.txt', 'never.txt', 'lang.txt', 'idem.txt',
];

test('all 10 payload files exist', () => {
  for (const f of PAYLOAD_FILES) {
    const p = path.join(PAYLOADS_DIR, f);
    assert.ok(fs.existsSync(p), `${f} does not exist`);
  }
});

test('hashes of all 10 payload files match payloads.sha256', () => {
  const hashContent = fs.readFileSync(HASH_FILE, 'utf-8');
  const recordedHashes = {};
  for (const line of hashContent.trim().split('\n')) {
    const parts = line.split(/\s+/);
    if (parts.length >= 2) {
      recordedHashes[parts[1]] = parts[0];
    }
  }

  for (const f of PAYLOAD_FILES) {
    const filePath = path.join(PAYLOADS_DIR, f);
    const content = fs.readFileSync(filePath);
    const hash = crypto.createHash('sha256').update(content).digest('hex');
    const relPath = 'payloads/' + f;
    assert.ok(recordedHashes[relPath], `no hash recorded for ${relPath}`);
    assert.strictEqual(hash, recordedHashes[relPath],
      `${f}: hash mismatch (expected ${recordedHashes[relPath]}, got ${hash})`);
  }
});
