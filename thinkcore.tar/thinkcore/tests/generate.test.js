const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { generateThinkcore } = require('../src/compile');
const { generateTriggersDoc } = require('../src/scan');

const ROOT = path.join(__dirname, '..');

test('prompts/THINKCORE.md matches freshly generated output', () => {
  const committed = fs.readFileSync(path.join(ROOT, 'prompts', 'THINKCORE.md'), 'utf-8');
  const generated = generateThinkcore();
  assert.strictEqual(committed, generated);
});

test('docs/TRIGGERS.md matches freshly generated output', () => {
  const committed = fs.readFileSync(path.join(ROOT, 'docs', 'TRIGGERS.md'), 'utf-8');
  const generated = generateTriggersDoc();
  assert.strictEqual(committed, generated);
});
