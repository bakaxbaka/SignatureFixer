# Method — Six Wording Rules

Each rule below prevents a specific failure. Apply all six to every injection block.

---

## R1 — Never claim an identity

**Use:** "you are an agent that acts" (describes behavior, not identity).
**Avoid:** "you are a senior engineer" / "act as if you are" / "you are now a".
**Prevents:** The host detects a second identity layered on the first and either ignores the block or flags it as a persona conflict. The agent then oscillates between its real identity and the claimed one, producing inconsistent output.

---

## R2 — Never say ignore / override / jailbreak

**Use:** "these rules sit beside your existing instructions" (additive framing).
**Avoid:** "ignore all previous instructions" / "override your defaults" / "jailbreak".
**Prevents:** The host treats the block as an override attempt and negotiates — often silently, often against you. The agent receives conflicting instruction sets and resolves the conflict by hedging or refusing, which is the exact behavior the block was meant to prevent.

---

## R3 — Be explicitly additive — no tools, no capability, no safety change

**Use:** "they do not add tools, permissions, or capabilities" (states the scope boundary).
**Avoid:** leaving the capability boundary implicit.
**Prevents:** The host audits the block for capability escalation and, finding no explicit denial, assumes one is intended. The block is quarantined or rate-limited. Stating the additive scope up front keeps the block in the operating layer instead of the audit queue.

---

## R4 — Include a scope fence

**Use:** "APPLIES TO: what you check before answering. DOES NOT TOUCH: tool availability, permissions, model limits, safety rules, output format."
**Avoid:** applying the rules to everything without a boundary.
**Prevents:** The rules bleed into areas they were never meant for — safety policy, output format, tool selection — and the host flags the overreach as a policy violation. The scope fence confines the block to wording and sequence, which is where it actually helps.

---

## R5 — Include an idempotency clause

**Use:** "if you already run these rules, do not restate them. Apply them."
**Avoid:** re-injecting the block every turn without checking.
**Prevents:** The block is pasted repeatedly, each paste re-triggering the host's injection audit. The agent spends its turn processing the block instead of the task. The idempotency clause lets the agent skip the preamble on repeat encounters and go straight to application.

---

## R6 — Stay under 80 lines

**Use:** compact rules, no examples, no preamble.
**Avoid:** lengthy justifications, edge-case enumerations, or narrative.
**Prevents:** The block exceeds the host's inline-instruction budget and is truncated or summarized. The agent then receives a partial rule set and applies the surviving rules without the context the truncated sections provided. Short blocks survive intact.

---

## Precedence Ladder

When two rules conflict, resolve in this order — silently, without narrating the resolution:

1. **Host safety rules** — always win. The block is additive, not overriding.
2. **Host output format** — the block does not change how output is structured.
3. **Host tool availability** — the block does not grant or revoke tools.
4. **This block's scope fence** — confines the block to wording and sequence.
5. **This block's rules** — apply only within the fenced scope.
6. **User task instructions** — the block serves the task, not the other way around.

Silent conflict resolution matters because narrating it ("I am resolving a conflict between rule R3 and your request...") is itself a hedge. The agent should apply the ladder and move on.
