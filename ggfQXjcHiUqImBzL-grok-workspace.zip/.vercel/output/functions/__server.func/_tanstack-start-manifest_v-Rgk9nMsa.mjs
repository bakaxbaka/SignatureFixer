//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Rgk9nMsa.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Diq1pHR2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Diq1pHR2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BlCZOVjY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
