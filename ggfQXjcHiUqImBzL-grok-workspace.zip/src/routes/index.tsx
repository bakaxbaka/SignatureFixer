import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import bench from "../../index.html?raw";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = host.current;
    if (!el) return;
    const parsed = new DOMParser().parseFromString(bench, "text/html");
    const style = parsed.querySelector("style")?.textContent ?? "";
    const markup = parsed.querySelector("#tc")?.outerHTML ?? "";
    const code = parsed.querySelector("script")?.textContent ?? "";
    el.replaceChildren();
    const styleEl = document.createElement("style");
    styleEl.textContent = style;
    const wrap = document.createElement("div");
    wrap.innerHTML = markup;
    const script = document.createElement("script");
    script.textContent = code;
    el.append(styleEl, wrap, script);
    return () => {
      el.replaceChildren();
    };
  }, []);

  return <div ref={host} />;
}
